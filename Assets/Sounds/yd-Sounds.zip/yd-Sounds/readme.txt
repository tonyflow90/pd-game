Sound pack made by yd from http://opengameart.org

License: cc0/public domain http://creativecommons.org/publicdomain/zero/1.0/

Taken from: 
http://opengameart.org/content/platformer-sprites
